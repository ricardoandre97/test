#!/bin/bash

set -e

echo "Ensuring redis ..."
if ! command -v redis-cli --version > /dev/null 2>&1; then 
	sudo apt update && sudo apt install redis -y
fi

echo "Ensuring pip ..."
if ! command -v pip3 --version > /dev/null 2>&1; then
	curl -O https://bootstrap.pypa.io/get-pip.py && \
	python3 get-pip.py 
fi

echo "Ensuring python dependencies ..."
pip3 install -r ~/requirements.txt

echo "Starting app on port 8080 ..."
pkill -f "not_docker" || true
export REDIS_HOST="127.0.0.1"
nohup python3 ~/app.py not_docker > api.log 2>&1 &

echo "Waiting for the server to boot up ..."
sleep 2
if grep -iq error api.log; then
	echo "Error starting the server!"
	tail api.log
	exit 1 
fi

echo "Server is running on port 8080"
