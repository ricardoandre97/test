#!/bin/bash

set -e
redis-cli DEL hits
pkill -f "not_docker" || true
echo "All services were successfully stopped."

