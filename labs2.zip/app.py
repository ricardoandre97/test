import redis
from flask import Flask
from os import environ as env
from os import uname
from string import Template
from time import sleep

app = Flask(__name__)
cache = redis.Redis(host=env['REDIS_HOST'], port=6379)

def get_hit_count():
    retries = 5
    while True:
        try:
            return cache.incr('hits')
        except redis.exceptions.ConnectionError as exc:
            if retries == 0:
                raise exc
            retries -= 1
            sleep(0.5)
@app.route('/')
def hello():
    return Template('''<!DOCTYPE html>
    <html>
    <head>

        <meta charset="utf-8">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@700&display=swap" rel="stylesheet">
        <style>
            body {
              background-image: url('bg.png');
              background-size: 110%

            }
            h1 {
                font-family: 'Comfortaa', cursive;
                padding-top: 300px;
                font-size: 80px;
                color: #000;
            }
            .white {
                color: #fff;
            }
            .bold {
                color: #E1D9D1;
                font-family: 'Comfortaa', cursive;
                font-weight: bolder;
                font-size: 20px;
            }
            p {
                font-family: 'Comfortaa', cursive;
                font-size: 20px;
                color: #000;
                display: inline;
                font-weight: normal;
            }
        </style>
    </head>
    <body>
        <center>
                <h1>You've visited this website <span class="white">$COUNT </span> times!</h1>
                <p>Running on host </p><span class="bold">$HOSTNAME</p>
        </center>
    </body>
    </html>''').substitute(HOSTNAME=uname()[1], COUNT=get_hit_count())

if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True, port='8080')
